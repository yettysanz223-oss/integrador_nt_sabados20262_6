"""Tres graficas y conclusiones de la tabla registros (HU E6-REG-G01).

Lee data/limpio/registros_limpio.csv, arma tres graficas con matplotlib y las
guarda en reportes/ (registros_grafica_1.png, _2.png y _3.png). Al final
imprime las conclusiones.

Necesita pandas y matplotlib (pip install pandas matplotlib).
"""
import os

import matplotlib

matplotlib.use("Agg")  # sin ventana: el script solo guarda las imagenes
import matplotlib.pyplot as plt
import pandas as pd

# Columnas que necesitan las graficas (el archivo limpio ya trae la columna mes)
COLUMNAS = ["id", "estado", "id_usuario", "id_reto", "mes"]
# Resolucion de las imagenes
DPI = 120


def leer_datos(ruta_csv):
    """Lee el CSV limpio con pandas y crea la columna mes si no viene."""
    df = pd.read_csv(ruta_csv, encoding="utf-8")
    if "mes" not in df.columns and "fecha_registro" in df.columns:
        fechas = pd.to_datetime(df["fecha_registro"], errors="coerce")
        df = df.assign(mes=fechas.dt.to_period("M").astype(str).where(fechas.notna()))
    return df


def calcular_resultados(df):
    """Calcula lo que se grafica. Devuelve (conteo, por_mes, por_reto, top_retos)."""
    conteo = df["estado"].value_counts()
    por_mes = df.groupby("mes")["id"].count()
    por_reto = df.groupby("id_reto")["id"].count()
    top_retos = por_reto.nlargest(10)
    return conteo, por_mes, por_reto, top_retos


def grafica_1_por_estado(conteo, carpeta):
    """Grafica 1: barras con las participaciones por estado."""
    ruta = os.path.join(carpeta, "registros_grafica_1.png")
    plt.figure(figsize=(8, 5))
    conteo.plot(kind="bar", rot=0)
    plt.title("Participaciones por estado")
    plt.xlabel("Estado")
    plt.ylabel("Cantidad de participaciones")
    plt.tight_layout()
    plt.savefig(ruta, dpi=DPI)
    plt.close()
    return ruta


def grafica_2_por_mes(por_mes, carpeta):
    """Grafica 2: linea con las participaciones por mes."""
    ruta = os.path.join(carpeta, "registros_grafica_2.png")
    plt.figure(figsize=(8, 5))
    por_mes.plot(kind="line", marker="o", rot=45)
    plt.title("Participaciones por mes")
    plt.xlabel("Mes")
    plt.ylabel("Cantidad de participaciones")
    plt.tight_layout()
    plt.savefig(ruta, dpi=DPI)
    plt.close()
    return ruta


def grafica_3_top_retos(top_retos, carpeta):
    """Grafica 3: barras horizontales con los 10 retos con mas participantes."""
    ruta = os.path.join(carpeta, "registros_grafica_3.png")
    plt.figure(figsize=(8, 5))
    top_retos.plot(kind="barh")
    plt.gca().invert_yaxis()  # el reto con mas participantes queda arriba
    plt.title("Los 10 retos con mas participantes")
    plt.xlabel("Cantidad de participantes")
    plt.ylabel("Reto (id_reto)")
    plt.tight_layout()
    plt.savefig(ruta, dpi=DPI)
    plt.close()
    return ruta


def lideres_de(serie):
    """Devuelve (valor maximo, lista de etiquetas que lo alcanzan)."""
    maximo = serie.max()
    return maximo, [str(etiqueta) for etiqueta in serie[serie == maximo].index]


def unir_con_y(items):
    """Une una lista de textos para leerla en una frase: 'a, b y c'."""
    if len(items) <= 1:
        return "".join(items)
    return ", ".join(items[:-1]) + " y " + items[-1]


def contar_duplicadas(df):
    """Cuenta las inscripciones repetidas (mismo usuario en el mismo reto)."""
    pares = ["id_usuario", "id_reto"]
    sobrantes = int(df.duplicated(subset=pares, keep="first").sum())
    involucradas = int(df.duplicated(subset=pares, keep=False).sum())
    pares_repetidos = int(df[df.duplicated(subset=pares, keep=False)].drop_duplicates(subset=pares).shape[0])
    return sobrantes, involucradas, pares_repetidos


def construir_conclusiones(df, conteo, por_mes, por_reto):
    """Arma la lista de conclusiones (texto) a partir de los datos."""
    conclusiones = []

    maximo, retos = lideres_de(por_reto)
    if len(retos) == 1:
        conclusiones.append(f"1) El reto mas popular es el {retos[0]}, con {maximo} participantes.")
    else:
        conclusiones.append(
            f"1) Hay un empate por el reto mas popular: los retos {unir_con_y(retos)} "
            f"tienen {maximo} participantes cada uno."
        )

    if por_mes.empty:
        conclusiones.append("2) No se pudo calcular el mes con mas inscripciones: la columna mes esta vacia.")
    else:
        maximo, meses = lideres_de(por_mes)
        if len(meses) == 1:
            conclusiones.append(f"2) El mes con mas inscripciones fue {meses[0]}, con {maximo}.")
        else:
            conclusiones.append(
                f"2) Hubo un empate por el mes con mas inscripciones: {unir_con_y(meses)}, "
                f"con {maximo} cada uno."
            )

    sobrantes, involucradas, pares = contar_duplicadas(df)
    if sobrantes == 0:
        conclusiones.append(
            "3) Inscripciones duplicadas (mismo usuario en el mismo reto): 0 en este archivo; "
            "la limpieza ya dejo solo la primera participacion de cada par."
        )
    else:
        conclusiones.append(
            f"3) Inscripciones duplicadas (mismo usuario en el mismo reto): {sobrantes} sobrantes, "
            f"en {pares} pares repetidos ({involucradas} filas involucradas)."
        )
    conclusiones.append(
        "   El back debe bloquearlas con 409 (Conflict) porque la inscripcion ya existe: "
        "un usuario no puede estar dos veces en el mismo reto. Si se dejan pasar, se inflan "
        "los conteos de participantes y las graficas dejan de reflejar la realidad. "
        "Por eso el servicio revisa si ya existe el par (id_usuario, id_reto) antes de guardar "
        "y responde 409, en vez de crear otro registro."
    )

    estado = str(conteo.index[0])
    cantidad = int(conteo.iloc[0])
    porcentaje = cantidad * 100 / len(df)
    conclusiones.append(
        f"4) El estado mas frecuente es {estado}, con {cantidad} participaciones ({porcentaje:.1f}% del total)."
    )
    return conclusiones


def generar_reporte(ruta_csv="data/limpio/registros_limpio.csv", carpeta="reportes"):
    """Crea las tres graficas en `carpeta` e imprime las conclusiones.

    Devuelve la lista con las rutas de las tres imagenes.
    """
    if not os.path.exists(ruta_csv):
        raise FileNotFoundError(
            f"No existe {ruta_csv}. Primero hay que limpiar los datos (HU L01) "
            "para que se cree registros_limpio.csv."
        )

    df = leer_datos(ruta_csv)
    faltan = [c for c in COLUMNAS if c not in df.columns]
    if faltan:
        raise ValueError("Faltan columnas en el archivo: " + ", ".join(faltan))
    if df.empty:
        raise ValueError("El archivo no tiene filas para graficar.")

    conteo, por_mes, por_reto, top_retos = calcular_resultados(df)

    os.makedirs(carpeta, exist_ok=True)  # la carpeta se crea sola

    rutas = [
        grafica_1_por_estado(conteo, carpeta),
        grafica_2_por_mes(por_mes, carpeta),
        grafica_3_top_retos(top_retos, carpeta),
    ]

    print("Graficas guardadas:")
    for ruta in rutas:
        print(" ", ruta)
    print("\nConclusiones:")
    for linea in construir_conclusiones(df, conteo, por_mes, por_reto):
        print(linea)
    return rutas


if __name__ == "__main__":
    generar_reporte()
