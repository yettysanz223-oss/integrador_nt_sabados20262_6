"""Corre todo el flujo de `registros`: simulacion (F01), exportacion (X01),
limpieza (L01), consultas (Q01) y graficas (G01).

Ejecutar desde cualquier carpeta:
    python src/Notebook/main.py
"""
import os
from pathlib import Path

import pandas as pd

from consultas.consultas_registros import main as correr_consultas
from exportaciones.exportar_registros import exportar
from graficas.reporte_registros import generar_reporte
from limpiezas.limpiar_registros import main as correr_limpieza
from simulaciones.simular_registros import generar_registros

# Raiz del proyecto (main.py esta en src/Notebook/): asi data/ y reportes/
# siempre quedan en el mismo lugar, sin importar desde donde se ejecute.
RAIZ = Path(__file__).resolve().parents[2]
os.chdir(RAIZ)

RUTA_SUCIO = RAIZ / "data" / "crudo" / "registros_sucio.csv"
RUTA_LIMPIO = RAIZ / "data" / "limpio" / "registros_limpio.csv"
CARPETA_REPORTES = RAIZ / "reportes"

# Para ver todas las columnas al imprimir el DataFrame
pd.set_option("display.max_columns", None)
pd.set_option("display.width", 200)


def paso_simulacion_y_exportacion():
    """F01 + X01: simula los datos sucios, los revisa en pantalla y los exporta."""
    print("=== F01: simulación de registros ===")
    df = generar_registros()
    print(df.shape)
    print(df.head())
    print(df.isna().sum())

    print("\n=== X01: exportación a data/crudo/ ===")
    exportar(df)  # se exporta el mismo DataFrame que se acaba de revisar


def paso_limpieza():
    """L01: lee data/crudo/registros_sucio.csv y crea data/limpio/registros_limpio.csv."""
    print("\n=== L01: limpieza de registros ===")
    return correr_limpieza(["limpiar_registros.py", str(RUTA_SUCIO)])


def paso_consultas():
    """Q01: las cinco consultas sobre el archivo limpio."""
    print("\n=== Q01: consultas de registros ===")
    return correr_consultas(["consultas_registros.py", str(RUTA_LIMPIO)])


def paso_graficas():
    """G01: tres graficas y conclusiones a partir del archivo limpio."""
    print("\n=== G01: gráficas y conclusiones ===")
    generar_reporte(RUTA_LIMPIO, CARPETA_REPORTES)


def main():
    paso_simulacion_y_exportacion()
    if paso_limpieza() != 0:
        print("Se detuvo el flujo: falló la limpieza.")
        return 1
    if paso_consultas() != 0:
        print("Se detuvo el flujo: fallaron las consultas.")
        return 1
    paso_graficas()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
